let n1 = 2;
let n2 = 10;
do{
console.log(n1);
n1++
}while (n1 <= n2)