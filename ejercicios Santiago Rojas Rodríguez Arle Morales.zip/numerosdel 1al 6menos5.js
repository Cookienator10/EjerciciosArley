let n1 = 1;

function numeros() {
 while (n1 <= 6) {
   if (n1 != 5){
console.log(n1);
   }
   n1++
}
}
numeros();
